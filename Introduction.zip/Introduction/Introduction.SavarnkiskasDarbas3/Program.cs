﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.SavarnkiskasDarbas3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Result;
            double x, y;
            char sign;      //Operation sign
            Console.WriteLine("Įveskite pirma skaičių");
            x = int.Parse(Console.ReadLine());
            ;
            Console.WriteLine("Įveskite norimą ženklą");
            sign = Console.ReadLine()[0];
            Console.WriteLine("Įveskite antrą skaičių");
            y = int.Parse(Console.ReadLine());
            if (sign == '-')
            {
                Result = x - y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if (sign == '+')
            {
                Result = x + y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if (sign == '*' )
            {
                Result = x * y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if (sign == '/' ) 
            {
                Result = x / y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else
            {
                Console.WriteLine("Klaidinga Operacija");
            }

        }
    }
}
