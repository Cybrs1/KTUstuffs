﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.Loop.Step6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int j = 1;
            Console.WriteLine("Įveskite rėžių pradžią");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Įveskite rėžių pabaigą");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine("Skaičiai nuo 5 iki 15 ir jų kvadratai ir jų kubai");
            for (int i = a; i < b; i++)
                Console.WriteLine("{0} {1} {2} {3} {4} {5}", i, i * i, i * i * i, "Spausdinta ", j++, "kartą(-ų)");
            Console.ReadKey();

        }
    }
}
