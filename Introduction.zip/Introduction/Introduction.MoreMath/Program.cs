﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.MoreMath
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double functionResult;
            int a;
            double x;
            Console.WriteLine("Įveskite a reikšmė");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Įveskite x reikšmė");
            x = int.Parse(Console.ReadLine());
            if (x <= 0)
                functionResult = a * Math.Exp(-x);
            else if (x < 1)
                functionResult = 5 * a * x - 7;
            else
                functionResult = Math.Pow(x + 1, 0.5);
            Console.WriteLine(" Reikšmė a = {0}, reikšmė {1}, fx ž {2}", a, x, functionResult);
            Console.ReadKey();
        }
    }
}
