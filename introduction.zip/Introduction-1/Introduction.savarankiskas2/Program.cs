﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.savarankiskas2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double functionResult;
            double x;
            Console.WriteLine("Įveskite x reikšmė");
            x = double.Parse(Console.ReadLine());
            if ((x < 0) && (x >= -1))
                functionResult = (1 / (x + 5));
            else if (x < 1)
                functionResult = x + 1;
            else
                functionResult = Math.Sqrt(Math.Pow(2, x) + x + 1); ;
            Console.WriteLine(" reikšmė x {0}, fx = {1}", x, functionResult);
            Console.ReadKey();  
        }
    }
}
