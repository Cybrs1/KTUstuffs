﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.Methods.Step._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            char character;
            Console.WriteLine("Įveskite spausdinamą simbolį");
            character = Console.ReadLine()[0];
            Program.Display(character);
            Console.ReadKey();
        }
        static void Display(char CharacterToDisplay)
        {
            for (int i = 1; i<51; i++)
            {
                if (i % 5 == 0)
                    Console.WriteLine(CharacterToDisplay);
                else
                    Console.Write(CharacterToDisplay);
            }
            Console.WriteLine();
        }
    }
}
