﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.SavarnkiskasDarbas3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Result;
            double x, y;
            char sign;      
            Console.WriteLine("Įveskite pirma skaičių");
            x = double.Parse(Console.ReadLine());
            ;
            Console.WriteLine("Įveskite norimą ženklą");
            sign = Console.ReadLine()[0];
            Console.WriteLine("Įveskite antrą skaičių");
            y = double.Parse(Console.ReadLine());
            if (sign == '-')
            {
                Result = x - y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if (sign == '+')
            {
                Result = x + y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if (sign == '*' )
            {
                Result = x * y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if ((sign == '/') && (y != 0))
            {
                Result = x / y;
                Console.WriteLine("Gautas rezultatas {0}", Result);
            }
            else if ((sign == '/') && (y == 0))
            {
                Console.WriteLine("Dalyba iš 0 negalima");
            }
            else
            {
                Console.WriteLine("Klaidinga Operacija");
            }

        }
    }
}
