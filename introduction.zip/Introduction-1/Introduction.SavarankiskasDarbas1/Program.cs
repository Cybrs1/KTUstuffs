﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction.SavarankiskasDarbas1
{
    internal class Program
    {
        static void Main(string[] args)
        {
         char character;
            int amounteil, amountsymb,amountinline ;
         
          
         Console.WriteLine("įveskite spausdinamą simbolį");
         character = Console.ReadLine()[0];
          Console.WriteLine("Įveskite simbolių kiekį");
            amountsymb = int.Parse(Console.ReadLine());
          Console.WriteLine("Įveskite norima vienos eilutės simbolių kiekį");
            amountinline = int.Parse(Console.ReadLine());
            amounteil = amountsymb / amountinline;

            for (int i = 1; i <= amounteil; i++)
            {
                int j = 1;
                while (j<=amountinline)
                {
                    Console.Write(character);
                    j++;
                }
                Console.WriteLine();
            }

        }
    }
}
